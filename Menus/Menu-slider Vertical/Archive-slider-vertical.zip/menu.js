/*
Menu name : Slider Vertical
Author : geqr
Website : www.ma-maison-intelligente.fr
Tutorial : http://ma-maison-intelligente.fr/2020/04/un-menu-slider-pour-design-jeedom/
Origin : https://codepen.io/raptor5/pen/WxQvgw
Last Update : 20200705 - creation
 */
$(".menu-opener").click(function(){
  $(".menu-opener, .menu-opener-inner, .menu").toggleClass("active");
});
